# MC-Paint-resourcepack
Resource Pack for MC Paint

# Credits
Thanks to ZeroIceBear for creating Chinese translations and Rignchen for French translations.