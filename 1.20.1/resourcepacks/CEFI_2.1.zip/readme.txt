Спасибо за то что скачали наш ресурспак! В будущем мы планируем его
активно развивать. Спасибо всем за поддержку, за идеи и т.д.

Хочу поблагодарить свою команду, а именно: FIuGa, MOURT1N, cizhka, SayL1ks_, Milyan, Dravenitt, Zanellle.

Ждите обновлений.


###################################################################################

Thank you for downloading our resource pack! We plan to
actively develop it in the future. Thank you all for your support, ideas, etc.

I want to thank my team, namely: FIuGa, MOURT1N, cizhka, SayL1ks_, Milyan, Dravenitt, Zanellle.

Wait for updates.